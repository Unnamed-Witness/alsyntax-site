document.addEventListener('DOMContentLoaded', () => {
    console.log("A.L. Syntax site loaded successfully.");
});